#ifndef ENCODE
#define ENCODE

#include <fstream>
#include "kongo.hpp"
#include "hiei.hpp"

string encode(string text, const vector<map<char, double> >& gps);

#endif
