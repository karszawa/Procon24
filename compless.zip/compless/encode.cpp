#include "encode.hpp"


extern bool PRACTICE;


string memo(string text, const vector<map<char, double> >& gps, string header)
{
	bool rle = header[1] == '1';
	if(header[0] == '1') return header + Hiei().encode(text, gps[rle], rle);
	
	int index = 0;
	for(int i = 2; i < header.size(); i++) {
		index = ((index << 1) | (header[i] == '1'));
	}

	return header + Kongo().encode(text, gps[index], rle);
}

string encode(string text, const vector<map<char, double> >& gps)
{
	static string header = "";
	if(!PRACTICE && header != "") return memo(text, gps, header);

	int index_size = 0;
	vector<string> cans;

	// attempt any cases
	for(int i = 0; i < gps.size(); i++) {
		string index;

		for(int size = 0; (gps.size() >> (size+1)) != 0; size++) {
			index = string(1, ((i >> size) & 1) + '0') + index;
		}

		index_size = index.size();

		for(int j = 0; j < 2; j++) {
			try {
				cans.push_back("0" + string(1, '0' + j) + index + Kongo().encode(text, gps[i], j));
			} catch(NotGeneratedCode) { }
		}
	}

	try {
		cans.push_back("10" + Hiei().encode(text, gps[0], false));
		cans.push_back("11" + Hiei().encode(text, gps[1], true));
	} catch(NotGeneratedCode e) {
		cerr << e.invalid_char << "(" << int(e.invalid_char) << ") is invalid." << endl;
		return "";
	}

	assert(!cans.empty());

	// select the best one
	string ret = cans[0];
	for(string can : cans) {
		ret = (ret.size() > can.size() ? can : ret);
	}

	header = ret.substr(0, (ret[0] == '0' ? index_size : 0) + 2);

	return ret;
}


int main(int argc, char *argv[])
{
	PRACTICE = (argc >= 2 && strcmp(argv[1], "-p") == 0);
	
	vector<string> files;
	files.push_back("gps/1.txt");
	files.push_back("gps/2.txt");
	files.push_back("gps/3.txt");
	files.push_back("gps/4.txt");
	files.push_back("gps/5.txt");
	files.push_back("gps/6.txt");
	files.push_back("gps/7.txt");
	files.push_back("gps/8.txt");

	for(string text; getline(cin, text) && text != ""; ) {
		auto gps = read_gps_from_files(files);
		string res = binary_to_octal(encode(text, gps));
		cout << res << endl;

		cerr << "cerr: result(" << res.size() * 3.0 << ") / original(" << text.size() * 7.0 << ") = ";
		cerr << (res.size() * 3.0) / (text.size() * 7.0) * 100.0 << "%" << endl;

		int size = 0;
		for(int i = 1; i <= text.size(); i++) {
			//cout << binary_to_octal(encode(text.substr(0, i), gps)) << endl;

			string tmp = binary_to_octal(encode(text.substr(0, i), gps));

			if(tmp.size() < 6*9-2) size = max(size, i);
		}

		cerr << "cerr: " << size << " characters per packet " << endl;
	}
}

