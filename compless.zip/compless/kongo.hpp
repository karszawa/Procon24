#ifndef KONGO
#define KONGO

#include <iostream>
#include <algorithm>
#include <numeric>
#include <string>
#include <memory>
#include <vector>
#include <queue>
#include <map>
#include "akatsuki.hpp"

using namespace std;

typedef map<char, string> mCS;
typedef map<string, char> mSC;

class Kongo : public Coding
{
protected:
	void unfold(mCS& codes, mSC& inverse, Node node, string code);
	pair<mCS, mSC> init_codes(const map<char, double>& gp);
	
public:	
	Kongo();
	string encode(string origin, map<char, double> gp, bool rle);
	string decode(string origin, map<char, double> gp, bool rle);
};


#endif
