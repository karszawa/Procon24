#include "Hiei.hpp"

bool PRACTICE = false;

string Hiei::encode(string origin, map<char, double> gp, bool rle)
{
	if(rle) origin = toRLE(origin);
	
	const double D = 0.01;
	auto codes = init_codes(gp).first;
		
	string ret;

	for(int i = 0; i < origin.size(); i++) {
		if(codes[origin[i]] == "") throw NotGeneratedCode(origin[i]);
		
		ret += codes[origin[i]];

		gp[origin[i]] += D;
		codes = init_codes(gp).first;
	}

	return ret;
}

string Hiei::decode(string origin, map<char, double> gp, bool rle)
{
	const double D = 0.01;
	auto inverse = init_codes(gp).second;
		
	string ret;

	for(int i = 0; i < origin.size(); ) {
		for(int j = 1; i + j <= origin.size(); j++) {
			char c = inverse[origin.substr(i, j)];
			if(c != 0) {
				ret += c;
				i += j;

				gp[c] += D;
				inverse = init_codes(gp).second;
				
				break;
			} else if(i + j >= origin.size()) i += j;
		}
	}

	return (rle ? fromRLE(ret) : ret);
}

