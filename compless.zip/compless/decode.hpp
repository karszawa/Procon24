#ifndef DECODE
#define DECODE

#include "kongo.hpp"
#include "hiei.hpp"

string decode(string text, vector<map<char, double> > gps, bool rle);

#endif

