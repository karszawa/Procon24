# README
## コンパイル方法

```
$ clang++ --version
Apple LLVM version 5.0 (clang-500.2.75) (based on LLVM 3.3svn)
Target: x86_64-apple-darwin12.5.0
Thread model: posix
$ clang++ -O3 -stdlib=libc++ -std=gnu++11 -Wall encode.cpp kongo.cpp hiei.cpp akatsuki.cpp -o encode
$ clang++ -O3 -stdlib=libc++ -std=gnu++11 -Wall decode.cpp kongo.cpp hiei.cpp akatsuki.cpp -o decode
```

## 使い方
圧縮率の行は標準エラー出力です。

```
$ ./encode
http://heyyeyaaeyaaaeyaeyaa.com
574072234524353225231053175533017363072435177346556
complession ratio = 70.5069%
http://heyyeyaaeyaaaeyaeyaa
57407223452435322523105317553301736307243514
complession ratio = 69.8413%
http://
5740722345243532252
complession ratio = 116.327%

$ ./decode
574072234524353225231053175533017363072435177346556
http://heyyeyaaeyaaaeyaeyaa.com
57407223452435322523105317553301736307243514
http://heyyeyaaeyaaaeyaeyaa
5740722345243532252
http://
```

