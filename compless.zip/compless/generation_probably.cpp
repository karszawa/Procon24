#include <iostream>
#include <iomanip>
#include <map>
using namespace std;

bool isValidChar(char c)
{
	return ('!' <= c && c <= 'Z') || ('_' <= c && c <= 'z');
}

int main()
{
	map<char, int> counts;
	map<char, double> gps;

	for(int c = 0; c < 128; c++) {
		if(isValidChar(c)) {
			counts[c] = 0.0;
		}
	}

	for(string line; cin >> line; ) {
		for(char c : line) {
			if(isValidChar(c)) {
				counts[c]++;
			}
		}
	}

	int all = 0;
	for(auto p : counts) {
		all += p.second;
	}

	for(auto p : counts) {
		gps[p.first] = 1.0 * p.second / all;
	}

	for(auto p : gps) {
		cout << p.first << " " << setprecision(16) << p.second << endl;
	}
}
	

	 
