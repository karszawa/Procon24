#ifndef AKATSUKI
#define AKATSUKI

#include <iostream>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <algorithm>
#include <cassert>
#include <vector>
#include <cassert>
#include <cstdio>
#include <cmath>
#include <numeric>
#include <queue>
#include <map>
#include <memory>


using namespace std;

typedef unsigned long long int int64;

class Coding
{
public:
	struct Node
	{
		char chr;
		double gp;
		shared_ptr<Node> right, left;

		Node(char chr, double gp, shared_ptr<Node> right, shared_ptr<Node> left) :
			chr(chr), gp(gp), right(right), left(left) { }
	};

	virtual string encode(string, map<char, double>, bool) = 0;
	virtual string decode(string, map<char, double>, bool) = 0;

	string to_b(int64 x);

	void base_gp(map<char, double> gp);
};

bool operator < (Coding::Node right, Coding::Node left);
bool operator > (Coding::Node right, Coding::Node left);

map<char, double> read_gp_from_file(string file);
vector<map<char, double>> read_gps_from_files(vector<string> files);

class NotGeneratedCode : public exception
{
public:
	char invalid_char;
	NotGeneratedCode(char c) : invalid_char(c) { }
};

bool isControlChar(char c);
int toControlChar(char c);
char fromControlChar(int i);

string toControlString(int n);

string toRLE(string text);

string fromRLE(string rle);

string binary_to_octal(string binary);
string octal_to_binary(string octal);

#endif
