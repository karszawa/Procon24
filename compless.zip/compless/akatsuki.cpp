#include "akatsuki.hpp"

string Coding::to_b(int64 x)
{
	string ret;

	for(; x != 0; x >>= 1) {
		ret += ('0' + (x & 1));
	}

	return ret;
}

void Coding::base_gp(map<char, double> gp)
{
	const double B = 0.0001;
	if(gp.end() == find_if(gp.begin(), gp.end(), [](pair<char, double> p){ return p.second == 0.0; })) {
		for(auto &p : gp) {
			p.second += B;
		}
	}
}

bool operator < (Coding::Node right, Coding::Node left)
{ return right.gp < left.gp; }

bool operator > (Coding::Node right, Coding::Node left)
{ return right.gp > left.gp; }

vector<map<char, double>> read_gps_from_files(vector<string> files)
{
	vector<map<char, double>> gps;
	
	for(string file : files) {
		gps.push_back(read_gp_from_file(file));
	}

	return gps;
}

map<char, double> read_gp_from_file(string file)
{
	ifstream ifs(file);

	if(ifs.fail()) {
		cerr << file << " does not exist." << endl;
		exit(0);
	}
	
	map<char, double> gp;
	for(string line; getline(ifs, line); ) {
		char c;
		double p;
		sscanf(line.data(), "%c %lf\n", &c, &p);
		gp[c] = p;
	}

	return gp;
}

bool isControlChar(char c)
{
	return c == ' ' || c == '\t' || ('Z' < c && c < '_') || 'z' < c;
}

char toControlChar(int i)
{
	if(i == 0) return ' ';
	if(i == 1) return '\t';
	if(2 <= i && i <= 5) return 'Z' + i - 1;
	if(6 <= i && i <= 9) return 'z' + i - 5;
	throw range_error("toNumChar accepts only 1-digit integer. But this integer is " + string(1, i));
}

int fromControlChar(char c)
{
	if(c == ' ') return 0;
	if(c == '\t') return 1;
	if('Z' < c && c < '_') return c - 'Z' + 1;
	if('z' < c) return c - 'z' + 5;
	throw range_error("fromNumChar accepts only control character. But this character is " + string(1, c));
}

string toControlString(int n)
{
	stringstream ss; ss << n;
	string s = ss.str();

	for(int i = 0; i < s.size(); i++) s[i] = toControlChar(s[i] - '0');
	
	return s;
}

string toRLE(string text)
{
	vector<pair<char, int> >  counts;

	for(int i = 0, cnt = 1; i < text.size(); i++) {
		if(i + 1 == text.size() || text[i] != text[i+1]) {
			counts.push_back(make_pair(text[i], cnt));
			cnt = 1;
		} else cnt++;
	}

	string res;
	for(auto p : counts) {
		res += string(1, p.first) + (p.second == 1 ? "" : toControlString(p.second));
	}

	return res;
}

string fromRLE(string rle)
{
	string res;

	int cnt = 0;
	char chr = rle[0];
	
	for(int i = 1; i < rle.size(); i++) {
		if(isControlChar(rle[i])) {
			cnt = cnt * 10 + fromControlChar(rle[i]);
		}	else {
			res += string(cnt ? cnt : 1, chr);
			cnt = 0;
			chr = rle[i];
		}

		if(i + 1 == rle.size()) res += string(cnt ? cnt : 1, chr);
	}

	return res;
}


string binary_to_octal(string binary)
{
	string octal;

	while(binary.size() % 3 != 0) binary += "0";

	for(int i = 0; i < binary.size(); i += 3) {
		char next = '0';
		for(int j = 0; j < 3; j++) {
			next += (binary[i+j]-'0')*(1<<(2-j));
		}
		octal.push_back(next);
	}

	return octal;
}

string octal_to_binary(string octal)
{
	string binary;

	for(char c : octal) {
		assert('0' <= c && c <= '7');
		
		for(int i = 2; i >= 0; i--) {
			binary.push_back('0'+(((c-'0')>>i)&1));
		}
	}

	return binary;
}
