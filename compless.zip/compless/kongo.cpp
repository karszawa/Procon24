#include "kongo.hpp"


vector<shared_ptr<Coding::Node> > heap;

Kongo::Kongo()
{
	while(heap.size() < 256) {
		heap.push_back(shared_ptr<Node>(new Node(0, 0, shared_ptr<Node>(), shared_ptr<Node>())));
	}
}

void Kongo::unfold(mCS& codes, mSC& inverse, Node node, string code)
{
	if(node.chr != 0) {
		codes[node.chr] = code;
		inverse[code] = node.chr;
	} else {
		unfold(codes, inverse, *node.right, code + "0");
		unfold(codes, inverse, *node.left , code + "1");
	}		
}

pair<mCS, mSC> Kongo::init_codes(const map<char, double>& gp)
{
	priority_queue<Node, vector<Node>, greater<Node> > que;

	for(auto p : gp) {
		que.push(Node(p.first, p.second, shared_ptr<Node>(), shared_ptr<Node>()));
	}

	for(int hi = 0; que.size() > 1; ) {
		auto n1 = que.top(); que.pop();
		auto n2 = que.top(); que.pop();

		auto right = heap[hi++]; (*right) = n1;
		auto left = heap[hi++]; (*left) = n2;
			
		que.push(Node(0, n1.gp + n2.gp, right, left));
	}

	mCS codes;
	mSC inverse;

	unfold(codes, inverse, que.top(), "");
	return make_pair(codes, inverse);
}

string Kongo::encode(string origin, map<char, double> gp, bool rle)
{
	if(rle) origin = toRLE(origin);

	auto codes = init_codes(gp).first;
	
	string ret;

	for(char c : origin) {
		if(codes[c] == "") throw NotGeneratedCode(c);
		ret += codes[c];
	}

	return ret;
}

string Kongo::decode(string origin, map<char, double> gp, bool rle)
{
	auto inverse = init_codes(gp).second;
		
	string ret;

	for(int i = 0; i < origin.size(); ) {
		for(int j = 1; i + j <= origin.size(); j++) {
			if(inverse[origin.substr(i, j)] != 0) {
				ret += inverse[origin.substr(i, j)];
				i += j;
				break;
			} else if(i + j >= origin.size()) i += j;
		}
	}

	return (rle ? fromRLE(ret) : ret);
}

