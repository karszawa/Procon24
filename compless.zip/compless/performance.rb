# /usr/bin/env ruby

N = (ARGV[0] ? ARGV[0].to_i : 100)
L = (ARGV[1] ? ARGV[1].to_i : 4000)

def random_problem_string(length)
  (1..length).map{ (('!'..'9').to_a + (':'..'Z').to_a + ('_'..'z').to_a).sample }.join
end

def measure(&block)
  t0 = Time.now
  ret = block.call
  span = Time.now - t0
  return ret, span
end

S = random_problem_string(L)

IO.popen("./encode", "r+") do |encode|
  IO.popen("./decode", "r+") do |decode|
    File.open("./log.txt", "a") do |file|
      time1, time2 = 0.0, 0.0
      ratios = 0.0

      N.times do |i|
        origin = random_problem_string(L)
        file.puts ("origin: " + origin)

        en, t1 = measure do
          encode.puts origin
          encode.gets.chomp
        end

        file.puts ("encode: " + en)

        de, t2 = measure do
          decode.puts en
          decode.gets.chomp
        end

        file.puts ("decode: " + de)

        ratio = (en.size * 3.0) / (origin.size * 7.0) * 100.0

        ratios += ratio
        time1 += t1
        time2 += t2

        if(origin == de)
          puts "CASE#{i}(AC): #{sprintf("%.1f", ratio)}% #{sprintf("%.3fs %.3fs", t1, t2)}"
        else
          puts "CASE#{i}(WA):"
          puts ("origin: " + origin)
          puts ("encode: " + en)
          puts ("decode: " + de)
        end
      end

      puts "SETTING: N=#{N} L=#{L}"
      puts "AVERAGE: #{sprintf("%.1f", ratios / N)}% #{sprintf("%.3fs, %.3fs", time1 / N, time2 / N)}"
    end
  end
end
