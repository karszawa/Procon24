require 'scanf'


gp = []
while (line = gets) != "\n" && line
  gp << line.scanf("%c %f")
end

gp.sort.map{ |p| p[0] }.zip(gp.sort.reverse.map{ |p| p[1] }).each do |p|
  puts p.join(' ')
end
