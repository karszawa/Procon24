#ifndef HIEI
#define HIEI

#include <iostream>
#include <algorithm>
#include <numeric>
#include <memory>
#include <vector>
#include <queue>
#include <map>
#include "akatsuki.hpp"
#include "kongo.hpp"
using namespace std;

class Hiei : public Kongo
{
public:
	string encode(string origin, map<char, double> gp, bool rle);
	string decode(string origin, map<char, double> gp, bool rle);
};

#endif
