#include "decode.hpp"

string decode(string text, vector<map<char, double> > gps)
{
	bool rle = text[1] == '1';
	
	if(text[0] == '1') return Hiei().decode(text.substr(2), gps[rle], rle);

	int index = 0, size = 0;

	for(size = 0; (gps.size() >> (size+1)) != 0; size++) {
		index = (index << 1) | (text[2+size] == '1');
	}

	return Kongo().decode(text.substr(2 + size), gps[index], rle);
}

int main()
{
	vector<string> files;
	files.push_back("gps/1.txt");
	files.push_back("gps/2.txt");
	files.push_back("gps/3.txt");
	files.push_back("gps/4.txt");
	files.push_back("gps/5.txt");
	files.push_back("gps/6.txt");
	files.push_back("gps/7.txt");
	files.push_back("gps/8.txt");

	for(string text; getline(cin, text) && text != ""; ) {
		cout << decode(octal_to_binary(text), read_gps_from_files(files)) << endl;
	}
}
