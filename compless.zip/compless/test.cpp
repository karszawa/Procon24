#include <iostream>
#include <vector>
#include <map>
#include <fstream>
#include "kongo.cpp"
using namespace std;

vector<map<char, double>> read_gps_from_file(vector<string> files)
{
	vector<map<char, double>> gps;
	
	for(string file : files) {
		ifstream ifs(file);

		if(ifs.fail()) {
			cerr << file << " does not exist." << endl;
			exit(0);
		}

		map<char, double> gp;
		for(string line; getline(ifs, line); ) {
			char c;
			double p;
			sscanf(line.data(), "%c %lf\n", &c, &p);
			cout << c << " " << p << endl;
			gp[c] = p;
		}

		gps.push_back(gp);
	}

	return gps;
}

int main()
{
	const char str[] = "”";
	cout << str << endl;
	
	auto gps = read_gps_from_file(vector<string>{ "gps/2.txt" });
	auto text = string(252, 'e');
	cout << toRLE(text) << endl;
	cout << Kongo().encode(text, gps[0], true) << endl;
}
